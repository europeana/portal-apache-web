Europeana Developers:

when updating schema's you need to update the redirecting configuration.
Open /ROOT/src/main/java/eu/europeana/web/servlet/SchemaMapping.java

More documentation is found there!